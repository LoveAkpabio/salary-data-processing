# Set working directory to where the zipped file is located
setwd("C:/Users/LOVE UMB/Desktop/NexFord Uni/BAN6420/Mod 2")

# Unzip the file
unzip("Employee_Profile.zip")

# Read the CSV file (replace the file name with the correct name from the zip)
data <- read.csv("NATHANIEL FORD_details.csv")

# Display the data
print(head(data))
