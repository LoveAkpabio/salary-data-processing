This paper covers the processing and exporting of salaries data using both Python and R.

#Project Overview

This project includes filtering a dataset with the salary information, writing the selected few employees’ data into a CSV file and finally zipping the file using python. The variable is then unzipped and shown in the R utility using the zipped file in the course of the last step.

#Project Steps

#Dataset Loading (Python):
Used pandas to read and explore a csv file of salary data of employees.
Shown the initial 5 rows to check correct data.

#Employee Details Retrieval (Python):
This implementation of a Python function was written to bring up employee information for a specific worker.
Repeated same above Robber barons and brought out the data required for NATHANIEL FORD and put it into my notebook.

#Exporting Employee Data (Python):
Saved NATHANIEL FORD’s data into a CSV file format.
Compressed the CSV file for safety to store and for transfer over the internet.

#Unzipping the File (R):
In the next step, the zipped file was extracted in R using the command unzip.
First, the unzipped CSV file opened in R was visualized to ensure proper and total file loading.

#Requirements

Python:
Python 3.x
pandas library ( pip install pandas)

R:
RStudio or any R environment
base package which is included in utils package

#How to Run the Project

Python:
Install required libraries: pip install pandas.
Processing and exporting an employee data involves loading and running a Python notebook.
After exporting, make sure that the result is in a zipped CSV format.

R:
Navigate to the directory where the data For Windows and Linux programs the directory will be something like chord/working-directory-in-R while for the MAC it will be chord/MAC-GTT-Working-Directory-R.
Execute the following R script that unzips ans displays data in the zipped file.